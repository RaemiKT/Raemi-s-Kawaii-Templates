Thank you for downloading this Etsy shop template!

---------------------------------------------------
INCLUDED FILES
---------------------------------------------------
- index.html (your shop website)
- style.css (styles and colors)
- product placeholder images
- readme.txt (this file)

---------------------------------------------------
HOW TO EDIT
---------------------------------------------------
1. Open index.html in any text editor (like VS Code or Notepad++).
2. Replace product names, prices, and Etsy links inside the <div class="card"> sections.
   Example:
   <h3>Moonlit Sticker Pack</h3>
   <p>$6.00</p>
   <a class="btn" href="https://www.etsy.com/shop/YOURSHOPNAME">Buy on Etsy</a>
3. To change images, replace the placeholder image URLs with your own image links.
   Example:
   <img src="https://via.placeholder.com/300x200" alt="Your Product">
   → Change to:
   <img src="your-image-file.jpg" alt="Your Product">
4. Save your changes.

---------------------------------------------------
HOW TO PUBLISH
---------------------------------------------------
Option 1: Free Hosting (recommended for beginners)
- Upload your folder to https://www.netlify.com or https://vercel.com (drag & drop).
- Your site will be live instantly with a free URL.

Option 2: GitHub Pages
- Create a free GitHub account.
- Upload your files.
- Enable "Pages" to publish.

Option 3: Custom Domain
- If you own a domain (like yourshop.com), connect it to Netlify, Vercel, or any hosting provider.

---------------------------------------------------
TIPS
---------------------------------------------------
- Keep your images optimized for faster loading.
- Make backups of your edited files.
- You can customize fonts and colors in style.css.

Enjoy your new shop website ✨
